# -*- coding: utf-8 -*-

from . import product_instance_slection
from . import inventory_instance_selection
from . import product_categ_instance
from . import product_attribute_instance
from . import product_attr_value_instance
from . import product_tag_instance
from . import tax_instance
from . import res_partner_instance
from . import so_instance
from . import product_variant_instance
from . import import_coupon_wizard
from . import import_shipping_method_wizard
from . import import_payment_gateway_wizard
from . import import_order_refund_wizard
