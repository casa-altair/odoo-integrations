# -*- coding: utf-8 -*-

from . import product_imp_exp
from . import customer_imp_ex
from . import tax_imp_ex
from . import so_imp_ex
from . import product_categ_imp_ex
from . import product_attr_imp_ex
from . import woo_multi_instance
from . import product_tag_imp_exp
from . import woo_coupon
from . import delivery_carrier
from . import payment_acquirer
from . import account_move
